# 欢迎使用 Fiddler Web Debugger中文版
## 汉化更新
 + 2020年04月26日升级至官方 `5.0.20202.18177`
## 下载方法
 + 直接克隆本项目或者在`releases`中下载打包好的压缩包
## 修改处理
 + 修改启动画面。
 + 去除通过WinConfig启动签名自校验。
 + Fiddler ScriptEditor 编辑器绿化。
## 插件说明
~~~
EnableLoopback.exe 用于捕获UWP应用（win8/8.1/10应用商店内的软件）
FiddlerCap.exe (单独用来捕获流量的软件)
ToE.dll (Fillder请求一键生成易语言代码)
FiddlerCheck.dll(已不提供更新检查)
~~~
## 使用异常
+ 如出现启动出错,请安装`.net framework 4.6.1`
## 闲言碎语
+ 如果你熟悉使用方法后也推荐尝试英文版。
+ 最后感谢各位土豪的打赏支持！
+ 欢迎Star关注。